var class_exceptions_1_1_out_of_bounds_exception =
[
    [ "OutOfBoundsException", "class_exceptions_1_1_out_of_bounds_exception.html#a345dda9584c4eafee9c2f84a01cc5cb3", null ],
    [ "getMessage", "class_exceptions_1_1_out_of_bounds_exception.html#a7a067f8cbac5143a73332388752d759b", null ]
];