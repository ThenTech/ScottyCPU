var annotated_dup =
[
    [ "CPUComponents", "namespace_c_p_u_components.html", "namespace_c_p_u_components" ],
    [ "Exceptions", "namespace_exceptions.html", "namespace_exceptions" ],
    [ "std", "namespacestd.html", "namespacestd" ],
    [ "Synchrotron", "namespace_synchrotron.html", "namespace_synchrotron" ],
    [ "SETTINGS", "struct_s_e_t_t_i_n_g_s.html", "struct_s_e_t_t_i_n_g_s" ]
];