var namespace_exceptions =
[
    [ "Exception", "class_exceptions_1_1_exception.html", "class_exceptions_1_1_exception" ],
    [ "FileReadException", "class_exceptions_1_1_file_read_exception.html", "class_exceptions_1_1_file_read_exception" ],
    [ "FileWriteException", "class_exceptions_1_1_file_write_exception.html", "class_exceptions_1_1_file_write_exception" ],
    [ "NullPointerException", "class_exceptions_1_1_null_pointer_exception.html", "class_exceptions_1_1_null_pointer_exception" ],
    [ "OutOfBoundsException", "class_exceptions_1_1_out_of_bounds_exception.html", "class_exceptions_1_1_out_of_bounds_exception" ]
];