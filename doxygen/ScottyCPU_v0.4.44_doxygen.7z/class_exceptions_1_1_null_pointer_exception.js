var class_exceptions_1_1_null_pointer_exception =
[
    [ "NullPointerException", "class_exceptions_1_1_null_pointer_exception.html#ab4d5ad24e767d3284f1f0f79581d7af9", null ],
    [ "getMessage", "class_exceptions_1_1_null_pointer_exception.html#a02e2924f33a2d015d99fd486248440f6", null ]
];