var class_exceptions_1_1_casting_exception =
[
    [ "CastingException", "class_exceptions_1_1_casting_exception.html#a31b5ac67ea5c2e90cb59b74e079cfd6a", null ],
    [ "getMessage", "class_exceptions_1_1_casting_exception.html#acdd855b6ac36d02ebce8e668bb0c626d", null ]
];