var class_exceptions_1_1_unexpected_extension =
[
    [ "UnexpectedExtension", "class_exceptions_1_1_unexpected_extension.html#a53a62f3cc7677aa855879c54b7872107", null ],
    [ "getMessage", "class_exceptions_1_1_unexpected_extension.html#a4a25fa9e86524bcee153bb046170aadd", null ]
];