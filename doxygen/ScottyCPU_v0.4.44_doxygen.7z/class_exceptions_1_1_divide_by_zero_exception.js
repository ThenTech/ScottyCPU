var class_exceptions_1_1_divide_by_zero_exception =
[
    [ "DivideByZeroException", "class_exceptions_1_1_divide_by_zero_exception.html#a46088114b9d6395774c79388c64724ec", null ],
    [ "getMessage", "class_exceptions_1_1_divide_by_zero_exception.html#adf38137a1824ae6d6e261646453c3b55", null ]
];