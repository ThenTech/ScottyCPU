var struct_c_p_u_instructions_1_1_instruction_info =
[
    [ "Op1_type", "struct_c_p_u_instructions_1_1_instruction_info.html#aec124727d7de22818f63320fad592b14", null ],
    [ "Op2_type", "struct_c_p_u_instructions_1_1_instruction_info.html#a5111be5b766f2f9a0618d07ffb7f7090", null ],
    [ "OpCode", "struct_c_p_u_instructions_1_1_instruction_info.html#ad44dc8848d3ecbae44d85fe7b1b69e38", null ]
];