var class_exceptions_1_1_file_write_exception =
[
    [ "FileWriteException", "class_exceptions_1_1_file_write_exception.html#a061d26d011acc86de1e2e78ebc0c1884", null ],
    [ "getMessage", "class_exceptions_1_1_file_write_exception.html#a698e39f225f0c433e12443d57eac0af7", null ]
];