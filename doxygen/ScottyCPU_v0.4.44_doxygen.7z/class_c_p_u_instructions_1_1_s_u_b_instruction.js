var class_c_p_u_instructions_1_1_s_u_b_instruction =
[
    [ "SUBInstruction", "class_c_p_u_instructions_1_1_s_u_b_instruction.html#a82d53d5a2b94f0c468df28793cc493b8", null ],
    [ "~SUBInstruction", "class_c_p_u_instructions_1_1_s_u_b_instruction.html#a8b335810f1114c06d7cd3d9aa228ad13", null ],
    [ "tick", "class_c_p_u_instructions_1_1_s_u_b_instruction.html#a899107f83b180dfdf7b0d1a6db4c9df3", null ]
];