var class_exceptions_1_1_exception =
[
    [ "Exception", "class_exceptions_1_1_exception.html#a62720db8647c4da81caced683a28abfe", null ],
    [ "~Exception", "class_exceptions_1_1_exception.html#a8c8d4652e5bb2cbbb96e2c1b08ef02ca", null ],
    [ "getMessage", "class_exceptions_1_1_exception.html#a94406e3b44461a6acbd98cd9ea13df8a", null ],
    [ "getMsg", "class_exceptions_1_1_exception.html#a92fdecc9c55347a098246a5be9cf13b7", null ],
    [ "_msg", "class_exceptions_1_1_exception.html#a3e8a1d8b8a52f82bfeedc04850c398f5", null ]
];