var _control_unit_8hpp =
[
    [ "ControlUnit", "class_c_p_u_components_1_1_control_unit.html", "class_c_p_u_components_1_1_control_unit" ],
    [ "EXTRA_CPU_REGISTERS", "_control_unit_8hpp.html#ac7f4561b6b593490552bee6a52c13d47", null ]
];