var class_exceptions_1_1_file_read_exception =
[
    [ "FileReadException", "class_exceptions_1_1_file_read_exception.html#ab8ec96df0777b60be8949ddc637ce172", null ],
    [ "getMessage", "class_exceptions_1_1_file_read_exception.html#a6ea3ae3dca78b67493af5bd503c1e1a4", null ]
];