var class_exceptions_1_1_out_of_bounds_exception =
[
    [ "OutOfBoundsException", "class_exceptions_1_1_out_of_bounds_exception.html#acf78deace11b6d0a60ef17523b275807", null ],
    [ "getMessage", "class_exceptions_1_1_out_of_bounds_exception.html#a1b474ff3728133770624fafef44be57a", null ]
];