var class_exceptions_1_1_null_pointer_exception =
[
    [ "NullPointerException", "class_exceptions_1_1_null_pointer_exception.html#a45a1b4623f93a4ca738aa3869bc783b4", null ],
    [ "getMessage", "class_exceptions_1_1_null_pointer_exception.html#a593e45389964b9ed8c0da60531105e9b", null ]
];