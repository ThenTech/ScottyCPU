var namespaces =
[
    [ "CPUComponents", "namespace_c_p_u_components.html", null ],
    [ "CPUInstructions", "namespace_c_p_u_instructions.html", null ],
    [ "Exceptions", "namespace_exceptions.html", null ],
    [ "std", "namespacestd.html", null ],
    [ "Synchrotron", "namespace_synchrotron.html", null ],
    [ "SysUtils", "namespace_sys_utils.html", null ]
];