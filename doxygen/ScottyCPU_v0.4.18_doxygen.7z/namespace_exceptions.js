var namespace_exceptions =
[
    [ "CastingException", "class_exceptions_1_1_casting_exception.html", "class_exceptions_1_1_casting_exception" ],
    [ "DivideByZeroException", "class_exceptions_1_1_divide_by_zero_exception.html", "class_exceptions_1_1_divide_by_zero_exception" ],
    [ "Exception", "class_exceptions_1_1_exception.html", "class_exceptions_1_1_exception" ],
    [ "FileReadException", "class_exceptions_1_1_file_read_exception.html", "class_exceptions_1_1_file_read_exception" ],
    [ "FileWriteException", "class_exceptions_1_1_file_write_exception.html", "class_exceptions_1_1_file_write_exception" ],
    [ "NullPointerException", "class_exceptions_1_1_null_pointer_exception.html", "class_exceptions_1_1_null_pointer_exception" ],
    [ "OutOfBoundsException", "class_exceptions_1_1_out_of_bounds_exception.html", "class_exceptions_1_1_out_of_bounds_exception" ]
];