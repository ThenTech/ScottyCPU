var class_exceptions_1_1_exception =
[
    [ "Exception", "class_exceptions_1_1_exception.html#a62720db8647c4da81caced683a28abfe", null ],
    [ "~Exception", "class_exceptions_1_1_exception.html#a8c8d4652e5bb2cbbb96e2c1b08ef02ca", null ],
    [ "getMessage", "class_exceptions_1_1_exception.html#aa808bad9995a37f0f400dfd9ce126789", null ],
    [ "_msg", "class_exceptions_1_1_exception.html#a3e8a1d8b8a52f82bfeedc04850c398f5", null ]
];