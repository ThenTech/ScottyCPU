var class_exceptions_1_1_file_write_exception =
[
    [ "FileWriteException", "class_exceptions_1_1_file_write_exception.html#ad880108c8c9321dbb825d03f180b1cde", null ],
    [ "getMessage", "class_exceptions_1_1_file_write_exception.html#abe162f5de58f97ee7512244f5247b3be", null ]
];