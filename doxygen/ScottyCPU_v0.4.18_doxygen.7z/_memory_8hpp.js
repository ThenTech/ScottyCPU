var _memory_8hpp =
[
    [ "Memory", "class_c_p_u_components_1_1_memory.html", "class_c_p_u_components_1_1_memory" ],
    [ "MemoryUnits", "_memory_8hpp.html#a48d08c2577010814bb2a3c942dbffaf5", [
      [ "BITS", "_memory_8hpp.html#a48d08c2577010814bb2a3c942dbffaf5a6886e0d29007ca152880b30d73ca2adc", null ],
      [ "BYTES", "_memory_8hpp.html#a48d08c2577010814bb2a3c942dbffaf5a9f1908a641ea399fd2e76f0905c88fcf", null ],
      [ "KILOBYTES", "_memory_8hpp.html#a48d08c2577010814bb2a3c942dbffaf5a8bdac1c59b910777c2191ff22a7b87d8", null ],
      [ "MEGABYTES", "_memory_8hpp.html#a48d08c2577010814bb2a3c942dbffaf5a63f5e2c1fcc77ace72cc84acabd7450c", null ]
    ] ],
    [ "memoryUnitToString", "_memory_8hpp.html#a9b27c44b07bd6ad4dd8d7e1157e789bc", null ]
];