var namespacestd =
[
    [ "FloatingBitset", "classstd_1_1_floating_bitset.html", "classstd_1_1_floating_bitset" ],
    [ "SignedBitset", "classstd_1_1_signed_bitset.html", "classstd_1_1_signed_bitset" ]
];