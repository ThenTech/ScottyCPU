var class_exceptions_1_1_casting_exception =
[
    [ "CastingException", "class_exceptions_1_1_casting_exception.html#a73f17c79849f2dba94b83b39de29971e", null ],
    [ "getMessage", "class_exceptions_1_1_casting_exception.html#ac7e7dd22ea59c859fa86677e0834bed1", null ]
];