var struct_s_e_t_t_i_n_g_s =
[
    [ "clk_freq", "struct_s_e_t_t_i_n_g_s.html#ac449a404a5061d6ca0af44f798441f7d", null ],
    [ "debug", "struct_s_e_t_t_i_n_g_s.html#a5e2842b08dc8b9306379eaa250a01f83", null ],
    [ "version", "struct_s_e_t_t_i_n_g_s.html#a00fb682cc3d1af12ba0057d2ab226f67", null ]
];