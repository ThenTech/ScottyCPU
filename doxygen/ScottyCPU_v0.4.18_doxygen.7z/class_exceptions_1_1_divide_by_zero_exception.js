var class_exceptions_1_1_divide_by_zero_exception =
[
    [ "DivideByZeroException", "class_exceptions_1_1_divide_by_zero_exception.html#a22c5632753a05178f21bc9f4f79c54eb", null ],
    [ "getMessage", "class_exceptions_1_1_divide_by_zero_exception.html#a7a1552e0e0234a174793a62e80da34f7", null ]
];