var utils_8hpp =
[
    [ "UNICODE", "utils_8hpp.html#a09ecca53f2cd1b8d1c566bedb245e141", null ],
    [ "allocArray", "utils_8hpp.html#a92a098eb0a309d834d678ee06b6a3100", null ],
    [ "allocArray", "utils_8hpp.html#ae16e8d13e9350307ce6cf02f1b201fcf", null ],
    [ "allocArray", "utils_8hpp.html#ab62a826ff966fa5765f3eb59145162c2", null ],
    [ "allocVar", "utils_8hpp.html#ad9dff63b2b59a27ae410061fdee1e62c", null ],
    [ "callSystemCmd", "utils_8hpp.html#a336903f3c008052a5a785c52ff3c6ece", null ],
    [ "convert2WSTR", "utils_8hpp.html#ae7b5c5d4754c477e0c48734e635af190", null ],
    [ "setTitle", "utils_8hpp.html#ad041739a5ee6fe79214d86c58ea50e97", null ],
    [ "setWindowTitle", "utils_8hpp.html#a0f26ea2cb81507a2aeab1694cd5c1ee7", null ],
    [ "strReplaceAll", "utils_8hpp.html#aa9a68109e3a087b585abbe28c01c5253", null ],
    [ "type2name", "utils_8hpp.html#aff0eb3177f3a99ee32ebb7729648e413", null ]
];