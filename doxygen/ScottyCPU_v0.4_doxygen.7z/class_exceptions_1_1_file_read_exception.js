var class_exceptions_1_1_file_read_exception =
[
    [ "FileReadException", "class_exceptions_1_1_file_read_exception.html#a53737e1355f4461214ddfc7de362fca6", null ],
    [ "getMessage", "class_exceptions_1_1_file_read_exception.html#a8b177f33e24fd06503c09838de62473c", null ]
];