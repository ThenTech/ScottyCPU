var annotated_dup =
[
    [ "CPUComponents", "namespace_c_p_u_components.html", "namespace_c_p_u_components" ],
    [ "Exceptions", "namespace_exceptions.html", "namespace_exceptions" ],
    [ "Synchrotron", "namespace_synchrotron.html", "namespace_synchrotron" ]
];